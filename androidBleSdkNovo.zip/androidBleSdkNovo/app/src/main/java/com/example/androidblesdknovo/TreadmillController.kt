package com.example.androidblesdknovo
//
//import android.Manifest
//import android.bluetooth.*
//import android.content.Context
//import android.content.pm.PackageManager
//import android.util.Log
//import androidx.core.app.ActivityCompat
//import java.util.UUID
//
//// Clase encargada de gestionar la conexión y el control de la caminadora
//class TreadmillController(private val context: Context) {
//    private val bluetoothAdapter: BluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
//    private var bluetoothGatt: BluetoothGatt? = null
//    private var treadmillService: BluetoothGattService? = null
//
//    companion object {
//        private const val TAG = "TreadmillController"
//        private val FTMS_SERVICE_UUID = UUID.fromString("00001826-0000-1000-8000-00805f9b34fb") // UUID del servicio FTMS
//        private val CHARACTERISTIC_SPEED_UUID = UUID.fromString("00002ad2-0000-1000-8000-00805f9b34fb") // UUID de la característica de velocidad
//        private val CHARACTERISTIC_INCLINE_UUID = UUID.fromString("00002ad3-0000-1000-8000-00805f9b34fb") // UUID de la característica de inclinación
//        private val CHARACTERISTIC_FAN_UUID = UUID.fromString("00002ad4-0000-1000-8000-00805f9b34fb") // UUID de la característica del ventilador
//        private val CHARACTERISTIC_START_STOP_UUID = UUID.fromString("00002ad5-0000-1000-8000-00805f9b34fb") // UUID de la característica de inicio/parar
//    }
//
//    // Función para conectar a un dispositivo Bluetooth específico
//    fun connectToDevice(device: BluetoothDevice) {
//        Log.d(TAG, "Intentando conectar al dispositivo: ${device.name}")
//        if (ActivityCompat.checkSelfPermission(
//                this,
//                Manifest.permission.BLUETOOTH_CONNECT
//            ) != PackageManager.PERMISSION_GRANTED
//        ) {
//            // TODO: Consider calling
//            //    ActivityCompat#requestPermissions
//            // here to request the missing permissions, and then overriding
//            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//            //                                          int[] grantResults)
//            // to handle the case where the user grants the permission. See the documentation
//            // for ActivityCompat#requestPermissions for more details.
//            return
//        }
//        bluetoothGatt = device.connectGatt(context, false, gattCallback)
//    }
//
//    // Callback GATT para manejar los eventos de la conexión y la comunicación con el dispositivo
//    private val gattCallback = object : BluetoothGattCallback() {
//        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
//            when (newState) {
//                BluetoothProfile.STATE_CONNECTED -> {
//                    Log.i(TAG, "Conectado al servidor GATT.")
//                    Log.d(TAG, "Descubriendo servicios...")
//                    if (ActivityCompat.checkSelfPermission(
//                            this,
//                            Manifest.permission.BLUETOOTH_CONNECT
//                        ) != PackageManager.PERMISSION_GRANTED
//                    ) {
//                        // TODO: Consider calling
//                        //    ActivityCompat#requestPermissions
//                        // here to request the missing permissions, and then overriding
//                        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//                        //                                          int[] grantResults)
//                        // to handle the case where the user grants the permission. See the documentation
//                        // for ActivityCompat#requestPermissions for more details.
//                        return
//                    }
//                    gatt.discoverServices()
//                }
//                BluetoothProfile.STATE_DISCONNECTED -> {
//                    Log.i(TAG, "Desconectado del servidor GATT.")
//                    closeConnection()
//                }
//                else -> {
//                    Log.e(TAG, "Estado de conexión inesperado: $newState")
//                }
//            }
//        }
//
//        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
//            if (status == BluetoothGatt.GATT_SUCCESS) {
//                treadmillService = gatt.getService(FTMS_SERVICE_UUID)
//                if (treadmillService != null) {
//                    Log.i(TAG, "Servicio FTMS descubierto.")
//                } else {
//                    Log.e(TAG, "Servicio FTMS no encontrado.")
//                }
//            } else {
//                Log.w(TAG, "onServicesDiscovered recibido con estado: $status")
//            }
//        }
//
//        // Método para cambiar la velocidad
//        fun setSpeed(speed: Float) {
//            writeCharacteristic(CHARACTERISTIC_SPEED_UUID, (speed * 100).toInt().toByte(), "velocidad")
//        }
//
//        // Método para cambiar la inclinación
//        fun setIncline(incline: Float) {
//            writeCharacteristic(CHARACTERISTIC_INCLINE_UUID, (incline * 100).toInt().toByte(), "inclinación")
//        }
//
//        // Método para controlar el ventilador
//        fun controlFan(turnOn: Boolean) {
//            writeCharacteristic(CHARACTERISTIC_FAN_UUID, if (turnOn) 1.toByte() else 0.toByte(), "ventilador")
//        }
//
//        // Método para iniciar o parar la caminadora
//        fun startStopTreadmill(start: Boolean) {
//            writeCharacteristic(CHARACTERISTIC_START_STOP_UUID, if (start) 1.toByte() else 0.toByte(), "inicio/parar")
//        }
//
//        // Método común para escribir en una característica
//        private fun writeCharacteristic(uuid: UUID, value: Byte, characteristicName: String) {
//            val characteristic = treadmillService?.getCharacteristic(uuid)
//            if (characteristic != null) {
//                characteristic.value = byteArrayOf(value)
//                Log.d(TAG, "Estableciendo $characteristicName a: ${value.toInt()}")
//                val success = bluetoothGatt?.writeCharacteristic(characteristic)
//                if (success == true) {
//                    Log.d(TAG, "Escritura en $characteristicName exitosa")
//                } else {
//                    Log.e(TAG, "Falló la escritura en la característica $characteristicName")
//                }
//            } else {
//                Log.e(TAG, "Característica $characteristicName no encontrada.")
//            }
//        }
//    }
//
//    // Función para desconectar y cerrar la conexión GATT
//    fun disconnect() {
//        Log.d(TAG, "Desconectando del servidor GATT.")
//        bluetoothGatt?.disconnect()
//        closeConnection()
//    }
//
//    // Cerrar la conexión de manera segura
//    private fun closeConnection() {
//        bluetoothGatt?.close()
//        bluetoothGatt = null
//        Log.d(TAG, "Conexión GATT cerrada.")
//    }
//}
